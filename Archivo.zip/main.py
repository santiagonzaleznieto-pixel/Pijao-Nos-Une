from pijao.ui.app import PijaoApp

if __name__ == "__main__":
    PijaoApp().run()
