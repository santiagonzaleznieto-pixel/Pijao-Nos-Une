import unittest

from pijao.data.localdb import LocalDB
from pijao.data.remoto import SinConexion
from pijao.servicios.aplicacion import Aplicacion


class RemotoFalso:
    def __init__(self, caido=False):
        self.caido = caido

    def iniciar_sesion(self, c, p):
        if self.caido:
            raise SinConexion()
        return {}

    def rpc(self, f, a=None):
        self.llamadas = getattr(self, "llamadas", []) + [(f, a)]
        if self.caido:
            raise SinConexion()
        if f == "rpc_invitar":
            return {"ok": True, "codigo": "ABC12345"}
        if f == "rpc_panel_campana":
            return {"viviendas_conocidas": 40, "viviendas_visitadas": 12, "hogares": 9, "personas_autorizadas": 20}
        return {"id": "u1", "nombre": "Ana", "rol": "admin", "estado": "activo", "permisos": []}

    def registrar(self, correo, clave, datos):
        self.registro = (correo, datos)
        return {}

    def cerrar_sesion(self):
        pass

    def seleccionar(self, t, p=None):
        if self.caido:
            raise SinConexion()
        return []


class TestAplicacion(unittest.TestCase):
    def setUp(self):
        self.app = Aplicacion(LocalDB(":memory:"), RemotoFalso())

    def test_login_guarda_perfil(self):
        p = self.app.iniciar_sesion("a@b.co", "x")
        self.assertEqual(p.nombre, "Ana")
        self.assertEqual(self.app.perfil_guardado().id, "u1")

    def test_login_vacio(self):
        with self.assertRaises(ValueError):
            self.app.iniciar_sesion("", "")

    def test_visita_sin_internet_queda_en_cola(self):
        self.app.iniciar_sesion("a@b.co", "x")
        d = self.app.nueva_visita(4.33, -75.7)
        self.assertEqual(len(self.app.errores_visita(d)), 1)
        d["visita"]["resultado"] = "nadie_en_casa"
        self.app.guardar_visita(d)
        self.assertEqual(self.app.estado_cola()["por_enviar"], 1)

    def test_visita_invalida(self):
        self.app.iniciar_sesion("a@b.co", "x")
        with self.assertRaises(ValueError):
            self.app.guardar_visita(self.app.nueva_visita(4.3, -75.7))

    def test_sin_conexion(self):
        self.app.remoto.caido = True
        self.assertTrue(self.app.sincronizar()["sin_conexion"])

    def test_invitar_y_permiso(self):
        self.app.iniciar_sesion("a@b.co", "x")
        self.assertTrue(self.app.puede_gestionar_equipo)
        r = self.app.invitar(" Luis ", "", "", "director")
        self.assertEqual(r["codigo"], "ABC12345")
        self.assertEqual(self.app.remoto.llamadas[-1][1], {"p_nombre": "Luis", "p_celular": None, "p_correo": None, "p_rol": "director"})

    def test_registro_con_codigo(self):
        self.assertIn("12", self.app.errores_registro({"codigo": "x", "nombre": "A", "correo": "a@b.co", "clave": "corta", "mayor": True}))
        self.app.registrar_con_codigo("Ana", "300", "a@b.co", "clave-larga-123", " ab12 ", True, False, "voluntario")
        self.assertEqual(self.app.remoto.registro[1]["codigo_invitacion"], "AB12")
        with self.assertRaises(ValueError):
            self.app.registrar_con_codigo("Ana", "", "a@b.co", "clave-larga-123", "AB12", False, False, "voluntario")

    def test_estadisticas_con_y_sin_internet(self):
        self.app.iniciar_sesion("a@b.co", "x")
        self.assertTrue(self.app.estadisticas()["en_linea"])
        self.assertEqual(self.app.estadisticas_locales()["casas"], 40)
        self.app.remoto.caido = True
        d = self.app.estadisticas()
        self.assertFalse(d["en_linea"])
        self.assertEqual(d["visitadas"], 12)


if __name__ == "__main__":
    unittest.main()
