import unittest

from pijao.data.localdb import LocalDB
from pijao.data.remoto import SinConexion
from pijao.servicios.aplicacion import Aplicacion


class RemotoFalso:
    def __init__(self, caido=False):
        self.caido = caido

    def iniciar_sesion(self, c, p):
        if self.caido:
            raise SinConexion()
        return {}

    def rpc(self, f, a=None):
        return {"id": "u1", "nombre": "Ana", "rol": "colaborador", "estado": "activo", "permisos": []}

    def cerrar_sesion(self):
        pass

    def seleccionar(self, t, p=None):
        if self.caido:
            raise SinConexion()
        return []


class TestAplicacion(unittest.TestCase):
    def setUp(self):
        self.app = Aplicacion(LocalDB(":memory:"), RemotoFalso())

    def test_login_guarda_perfil(self):
        p = self.app.iniciar_sesion("a@b.co", "x")
        self.assertEqual(p.nombre, "Ana")
        self.assertEqual(self.app.perfil_guardado().id, "u1")

    def test_login_vacio(self):
        with self.assertRaises(ValueError):
            self.app.iniciar_sesion("", "")

    def test_visita_sin_internet_queda_en_cola(self):
        self.app.iniciar_sesion("a@b.co", "x")
        d = self.app.nueva_visita(4.33, -75.7)
        self.assertEqual(len(self.app.errores_visita(d)), 1)
        d["visita"]["resultado"] = "nadie_en_casa"
        self.app.guardar_visita(d)
        self.assertEqual(self.app.estado_cola()["por_enviar"], 1)

    def test_visita_invalida(self):
        self.app.iniciar_sesion("a@b.co", "x")
        with self.assertRaises(ValueError):
            self.app.guardar_visita(self.app.nueva_visita(4.3, -75.7))

    def test_sin_conexion(self):
        self.app.remoto.caido = True
        self.assertTrue(self.app.sincronizar()["sin_conexion"])


if __name__ == "__main__":
    unittest.main()
