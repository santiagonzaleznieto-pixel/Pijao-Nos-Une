# Pijao nos une (Android, Python)

1. Crea el proyecto en Supabase y aplica `supabase/migrations/0001…0008` en orden.
2. Define `PIJAO_SUPABASE_URL` y `PIJAO_SUPABASE_ANON_KEY` (la clave `anon`, nunca la `service_role`).
3. Pruebas: `python -m unittest discover -s tests -t .`
4. Probar en el computador: `pip install -r requirements.txt && python main.py`
5. APK de descarga directa (Linux o WSL): `pip install buildozer && buildozer android debug` → `bin/*.apk`

Estado (v0.9.1): bienvenida animada, ingreso, Inicio al estilo de la referencia (franja, tarjeta de visitas, secciones con icono y nombre,
avance), mapa real con GPS y respaldo a satélite, registro de visitas, equipo (invitaciones, aprobar, suspender), perfil y pantalla de
errores. Revisión sin celular: `python tools/revisar_codigo.py` (código) y `python tools/probar_ui.py` (recorre toda la interfaz con un emulador de Kivy). Pruebas: `python -m unittest discover -s tests -t .`
Pendiente: curso y acuerdos para activar colaboradores, foto de fachada, hogar y personas en la visita, zonas, capas, mapa sin conexión,
estadísticas avanzadas, tareas, jornada y SOS.
