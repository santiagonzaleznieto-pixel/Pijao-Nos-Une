# Pijao nos une (Android, Python)

1. Crea el proyecto en Supabase y aplica `supabase/migrations/0001…0008` en orden.
2. Define `PIJAO_SUPABASE_URL` y `PIJAO_SUPABASE_ANON_KEY` (la clave `anon`, nunca la `service_role`).
3. Pruebas: `python -m unittest discover -s tests -t .`
4. Probar en el computador: `pip install -r requirements.txt && python main.py`
5. APK de descarga directa (Linux o WSL): `pip install buildozer && buildozer android debug` → `bin/*.apk`

Estado: núcleo, base de datos, sincronización sin conexión y pantallas de ingreso, mapa de puntos, visita y envío.
Pendiente: GPS real, mapa con teselas, fotos, personas/hogar en la visita, resto de pantallas del documento maestro y diseño final.
