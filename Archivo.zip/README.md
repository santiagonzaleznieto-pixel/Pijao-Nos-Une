# Pijao nos une (Android, Python)

1. Crea el proyecto en Supabase y aplica `supabase/migrations/0001…0008` en orden.
2. Define `PIJAO_SUPABASE_URL` y `PIJAO_SUPABASE_ANON_KEY` (la clave `anon`, nunca la `service_role`).
3. Pruebas: `python -m unittest discover -s tests -t .`
4. Probar en el computador: `pip install -r requirements.txt && python main.py`
5. APK de descarga directa (Linux o WSL): `pip install buildozer && buildozer android debug` → `bin/*.apk`

Estado (v0.7): ingreso, mapa real (calles/satélite) con tu ubicación y precisión, puntos por estado (color y forma),
ficha rápida, «Registrar aquí» con lectura de GPS de 9 s, revisión de duplicados a 15 m y bloqueo de «No contactar»,
formulario básico de visita y cola de envío con sincronización.
Pendiente (ver el documento maestro): visita completa (fachada, hogar, personas, necesidades, autorización), zonas, capas y filtros,
agrupación de puntos, mapa sin conexión, ubicación manual y registro diferido, paneles, equipo y tareas, jornada, SOS y diseño final.
