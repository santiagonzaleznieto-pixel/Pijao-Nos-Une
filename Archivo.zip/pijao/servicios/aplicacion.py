"""Lógica de la app sin Kivy: sesión, perfil, visitas y sincronización. Se prueba sin pantalla."""
from __future__ import annotations

from ..core import geo
from ..core import payload as pl
from ..core.catalogos import ESTADO_POR_RESULTADO
from ..core.permisos import Perfil
from ..data.localdb import LocalDB
from ..data.remoto import ErrorRemoto, Remoto, SinConexion
from ..data.sync import SyncEngine

RESULTADOS = list(ESTADO_POR_RESULTADO)


class Aplicacion:
    def __init__(self, db: LocalDB, remoto: Remoto, on_evento=None):
        self.db, self.remoto = db, remoto
        self.sync = SyncEngine(db, remoto, on_evento)
        self.perfil: Perfil | None = None

    # ------------------------------------------------------------ sesión
    def iniciar_sesion(self, correo: str, contrasena: str) -> Perfil:
        if not correo or not contrasena:
            raise ValueError("Escribe tu correo y tu contraseña.")
        self.remoto.iniciar_sesion(correo.strip(), contrasena)
        self.perfil = Perfil.desde_rpc(self.remoto.rpc("rpc_mi_perfil"))
        self.db.set_meta("perfil", self.perfil.a_dict())
        return self.perfil

    def perfil_guardado(self) -> Perfil | None:
        d = self.db.get_meta("perfil")
        self.perfil = Perfil.desde_rpc(d) if d else None
        return self.perfil

    def cerrar_sesion(self) -> None:
        try:
            self.remoto.cerrar_sesion()
        except (SinConexion, ErrorRemoto):
            pass
        self.perfil = None
        self.db.borrar_meta("perfil")

    # ------------------------------------------------------------ mapa y visitas
    def puntos_mapa(self) -> list[dict]:
        return self.db.todas_las_viviendas_idx()

    def cercanas(self, lat: float, lng: float, radio_m: float = 15.0) -> list[tuple[dict, float]]:
        """Viviendas ya registradas a menos de `radio_m` (R-09/6.2: duplicados a 15 m)."""
        return geo.cercanos(self.puntos_mapa(), lat, lng, radio_m)

    def nueva_visita(self, lat: float, lng: float, precision_m: float | None = None, vivienda: dict | None = None) -> dict:
        if not self.perfil or not self.perfil.activo:
            raise PermissionError("Tu cuenta aún no está activa.")
        return pl.borrador_vacio(self.perfil.id, vivienda, lat=lat, lng=lng, precision_m=precision_m)

    @staticmethod
    def errores_visita(draft: dict) -> list[str]:
        e = []
        v = draft.get("vivienda", {})
        if v.get("lat") is None or v.get("lng") is None:
            e.append("Falta la ubicación de la casa.")
        if draft.get("visita", {}).get("resultado") not in RESULTADOS:
            e.append("Elige el resultado de la visita.")
        return e

    def guardar_visita(self, draft: dict, dispositivo: dict | None = None) -> str:
        """Deja la visita en la cola de envío (funciona sin internet). Devuelve el id de la visita."""
        e = self.errores_visita(draft)
        if e:
            raise ValueError(" ".join(e))
        datos, _fotos = pl.construir_payload(draft, dispositivo)
        return self.db.encolar("registrar_visita", datos, id=draft["id"])

    # ------------------------------------------------------------ sincronización
    def sincronizar(self) -> dict:
        try:
            return {"ok": True, **(self.sync.sincronizar() or {})}
        except SinConexion:
            return {"ok": False, "sin_conexion": True}
        except ErrorRemoto as ex:
            return {"ok": False, "error": ex.mensaje}

    def estado_cola(self) -> dict:
        return self.db.outbox_conteo()
