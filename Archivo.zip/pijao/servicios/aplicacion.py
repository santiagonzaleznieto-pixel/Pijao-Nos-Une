"""Lógica de la app sin Kivy: sesión, perfil, visitas y sincronización. Se prueba sin pantalla."""
from __future__ import annotations

from datetime import datetime

from ..core import geo
from ..core import payload as pl
from ..core.catalogos import ESTADO_POR_RESULTADO
from ..core.permisos import Perfil
from ..data.localdb import LocalDB
from ..data.remoto import ErrorRemoto, Remoto, SinConexion
from ..data.sync import SyncEngine

RESULTADOS = list(ESTADO_POR_RESULTADO)


class Aplicacion:
    def __init__(self, db: LocalDB, remoto: Remoto, on_evento=None):
        self.db, self.remoto = db, remoto
        self.sync = SyncEngine(db, remoto, on_evento)
        self.perfil: Perfil | None = None

    # ------------------------------------------------------------ sesión
    def iniciar_sesion(self, correo: str, contrasena: str) -> Perfil:
        if not correo or not contrasena:
            raise ValueError("Escribe tu correo y tu contraseña.")
        self.remoto.iniciar_sesion(correo.strip(), contrasena)
        self.perfil = Perfil.desde_rpc(self.remoto.rpc("rpc_mi_perfil"))
        self.db.set_meta("perfil", self.perfil.a_dict())
        return self.perfil

    def perfil_guardado(self) -> Perfil | None:
        d = self.db.get_meta("perfil")
        self.perfil = Perfil.desde_rpc(d) if d else None
        return self.perfil

    def cerrar_sesion(self) -> None:
        try:
            self.remoto.cerrar_sesion()
        except (SinConexion, ErrorRemoto):
            pass
        self.perfil = None
        self.db.borrar_meta("perfil")
        self.db.borrar_meta("tokens")

    # ------------------------------------------------------------ mapa y visitas
    def puntos_mapa(self) -> list[dict]:
        return self.db.todas_las_viviendas_idx()

    def cercanas(self, lat: float, lng: float, radio_m: float = 15.0) -> list[tuple[dict, float]]:
        """Viviendas ya registradas a menos de `radio_m` (R-09/6.2: duplicados a 15 m)."""
        return geo.cercanos(self.puntos_mapa(), lat, lng, radio_m)

    def nueva_visita(self, lat: float, lng: float, precision_m: float | None = None, vivienda: dict | None = None) -> dict:
        if not self.perfil or not self.perfil.activo:
            raise PermissionError("Tu cuenta aún no está activa.")
        return pl.borrador_vacio(self.perfil.id, vivienda, lat=lat, lng=lng, precision_m=precision_m)

    @staticmethod
    def errores_visita(draft: dict) -> list[str]:
        e = []
        v = draft.get("vivienda", {})
        if v.get("lat") is None or v.get("lng") is None:
            e.append("Falta la ubicación de la casa.")
        if draft.get("visita", {}).get("resultado") not in RESULTADOS:
            e.append("Elige el resultado de la visita.")
        return e

    def guardar_visita(self, draft: dict, dispositivo: dict | None = None) -> str:
        """Deja la visita en la cola de envío (funciona sin internet). Devuelve el id de la visita."""
        e = self.errores_visita(draft)
        if e:
            raise ValueError(" ".join(e))
        datos, _fotos = pl.construir_payload(draft, dispositivo)
        return self.db.encolar("registrar_visita", datos, id=draft["id"])

    # ------------------------------------------------------------ sincronización
    def sincronizar(self) -> dict:
        try:
            return {"ok": True, **(self.sync.sincronizar() or {})}
        except SinConexion:
            return {"ok": False, "sin_conexion": True}
        except ErrorRemoto as ex:
            return {"ok": False, "error": ex.mensaje}

    def estado_cola(self) -> dict:
        return self.db.outbox_conteo()

    # ------------------------------------------------------------ inicio: números
    def estadisticas_locales(self) -> dict:
        c = self.db.get_meta("estadisticas", {}) or {}
        pend = self.estado_cola()["por_enviar"]
        return {**c, "casas": c.get("casas", len(self.puntos_mapa())), "por_enviar": pend,
                "mis_visitas_hoy": c.get("mis_visitas_hoy", 0) + pend}

    def estadisticas(self) -> dict:
        """Números del Inicio desde el servidor; si no hay internet se muestran los últimos guardados."""
        en_linea = True
        try:
            panel = self.remoto.rpc("rpc_panel_campana") or {}
            hoy = datetime.now().astimezone().replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
            mias = self.remoto.seleccionar("visitas", {"select": "id", "usuario_id": f"eq.{self.perfil.id}", "fecha": f"gte.{hoy}",
                                                       "eliminado_en": "is.null"}) if self.perfil else []
            self.db.set_meta("estadisticas", {"casas": panel.get("viviendas_conocidas", 0), "visitadas": panel.get("viviendas_visitadas", 0),
                                              "hogares": panel.get("hogares", 0), "personas": panel.get("personas_autorizadas", 0),
                                              "mis_visitas_hoy": len(mias)})
        except (SinConexion, ErrorRemoto):
            en_linea = False
        return {**self.estadisticas_locales(), "en_linea": en_linea}

    # ------------------------------------------------------------ equipo y cuentas
    @property
    def puede_gestionar_equipo(self) -> bool:
        return bool(self.perfil and self.perfil.activo and self.perfil.rol in ("admin", "director"))

    def invitar(self, nombre: str, celular: str, correo: str, rol: str) -> dict:
        return self.remoto.rpc("rpc_invitar", {"p_nombre": nombre.strip(), "p_celular": celular.strip() or None,
                                               "p_correo": correo.strip() or None, "p_rol": rol})

    def equipo(self) -> list[dict]:
        return self.remoto.seleccionar("perfiles", {"select": "id,nombre_completo,rol,estado", "order": "creado_en.desc"})

    def aprobar(self, ident: str):
        return self.remoto.rpc("rpc_aprobar_usuario", {"p_id": ident})

    def suspender(self, ident: str, motivo: str):
        return self.remoto.rpc("rpc_suspender_usuario", {"p_id": ident, "p_motivo": motivo})

    def reactivar(self, ident: str):
        return self.remoto.rpc("rpc_reactivar_usuario", {"p_id": ident})

    @staticmethod
    def errores_registro(d: dict) -> str:
        if not d.get("codigo", "").strip():
            return "Escribe el código de invitación."
        if not d.get("nombre", "").strip():
            return "Escribe tu nombre completo."
        if "@" not in d.get("correo", ""):
            return "Escribe un correo válido."
        if len(d.get("clave", "")) < 12:
            return "La contraseña debe tener al menos 12 caracteres."
        if not d.get("mayor"):
            return "Solo pueden registrarse personas mayores de 18 años."
        return ""

    def registrar_con_codigo(self, nombre, celular, correo, clave, codigo, mayor, servidor, tipo):
        e = self.errores_registro({"nombre": nombre, "correo": correo, "clave": clave, "codigo": codigo, "mayor": mayor})
        if e:
            raise ValueError(e)
        return self.remoto.registrar(correo, clave, {
            "codigo_invitacion": codigo.strip().upper(), "nombre_completo": nombre.strip(), "celular": celular.strip(),
            "mayor_de_edad": True, "tipo_vinculacion": tipo, "es_servidor_publico": bool(servidor), "es_contratista_estado": bool(servidor)})
