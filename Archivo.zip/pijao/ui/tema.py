"""Identidad visual (azul, verde y naranja del logo) y piezas reutilizables."""
from __future__ import annotations

import os
import threading

from kivy.clock import Clock
from kivy.graphics import Color, Line, RoundedRectangle
from kivy.metrics import dp, sp
from kivy.properties import NumericProperty
from kivy.animation import Animation
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget

ASSETS = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "..", "assets"))
AZUL, AZUL_OSC = (.106, .247, .545, 1), (.043, .165, .376, 1)
VERDE, NARANJA, ROJO = (.18, .64, .45, 1), (.949, .549, .157, 1), (.80, .20, .20, 1)
FONDO, BLANCO, TEXTO, GRIS, LINEA = (.953, .965, .984, 1), (1, 1, 1, 1), (.10, .13, .20, 1), (.45, .50, .58, 1), (.88, .91, .95, 1)
CLARO = (.94, .95, .97, 1)


def pintar(w, color, radio=18, lados=None):
    """Fondo redondeado que acompaña al widget. Devuelve el Color para poder cambiarlo."""
    with w.canvas.before:
        c = Color(*color)
        f = RoundedRectangle(pos=w.pos, size=w.size, radius=lados or [dp(radio)] * 4)
    w.bind(pos=lambda _, v: setattr(f, "pos", v), size=lambda _, v: setattr(f, "size", v))
    return c


def etiqueta(texto, tam=14, color=TEXTO, negrita=False, **kw):
    l = Label(text=texto, font_size=sp(tam), color=color, bold=negrita, halign=kw.pop("halign", "left"),
              valign="middle", size_hint_y=None, **kw)
    l.bind(width=lambda w, v: setattr(w, "text_size", (v, None)))
    l.bind(texture_size=lambda w, s: setattr(w, "height", max(s[1], dp(20))))
    return l


class Tarjeta(BoxLayout):
    def __init__(self, color=BLANCO, radio=20, **kw):
        kw.setdefault("orientation", "vertical")
        kw.setdefault("padding", dp(16))
        kw.setdefault("spacing", dp(8))
        kw.setdefault("size_hint_y", None)
        super().__init__(**kw)
        pintar(self, color, radio)
        self.bind(minimum_height=lambda _, h: setattr(self, "height", h))


class Boton(Button):
    def __init__(self, texto, color=NARANJA, texto_color=BLANCO, radio=26, **kw):
        kw.setdefault("size_hint_y", None)
        kw.setdefault("height", dp(52))
        super().__init__(text=texto, background_normal="", background_down="", background_color=(0, 0, 0, 0),
                         color=texto_color, bold=True, **kw)
        self._base = color
        self._c = pintar(self, color, radio)
        self.bind(state=lambda _, e: setattr(self._c, "rgba", tuple(x * .85 for x in color[:3]) + (1,) if e == "down" else color))


class Campo(TextInput):
    def __init__(self, pista, clave=False, multilinea=False, **kw):
        kw.setdefault("size_hint_y", None)
        kw.setdefault("height", dp(96) if multilinea else dp(50))
        super().__init__(hint_text=pista, password=clave, multiline=multilinea, background_normal="", background_active="",
                         background_color=(0, 0, 0, 0), foreground_color=TEXTO, hint_text_color=(.6, .64, .7, 1),
                         cursor_color=AZUL, padding=[dp(16), dp(15), dp(16), dp(10)], write_tab=False, **kw)
        pintar(self, CLARO, 16)


class Girando(Widget):
    """Indicador de carga: arco naranja que gira suave."""
    angulo = NumericProperty(0)

    def __init__(self, **kw):
        super().__init__(size_hint=(None, None), size=(dp(56), dp(56)), **kw)
        self.bind(angulo=self._d, pos=self._d, size=self._d)
        self._d()

    def _d(self, *_):
        self.canvas.clear()
        r = self.width / 2 - dp(4)
        with self.canvas:
            Color(*LINEA)
            Line(circle=(self.center_x, self.center_y, r), width=dp(4))
            Color(*NARANJA)
            Line(circle=(self.center_x, self.center_y, r, self.angulo, self.angulo + 110), width=dp(4), cap="round")

    def iniciar(self):
        self.angulo = 0
        a = Animation(angulo=360, d=.9, t="linear")
        a.bind(on_complete=lambda *_: self.iniciar() if self.parent else None)
        a.start(self)


def en_hilo(trabajo, ok=None, fallo=None):
    """Corre una tarea de red sin congelar la pantalla."""
    def correr():
        try:
            r = trabajo()
        except Exception as e:                    # noqa: BLE001 - se muestra al usuario
            Clock.schedule_once(lambda dt: fallo(e) if fallo else None, 0)
            return
        Clock.schedule_once(lambda dt: ok(r) if ok else None, 0)
    threading.Thread(target=correr, daemon=True).start()


def texto_error(e) -> str:
    m = getattr(e, "mensaje", None) or str(e)
    if e.__class__.__name__ == "SinConexion":
        return "Sin conexión a internet."
    for ing, esp in (("Invalid login", "Correo o contraseña incorrectos."), ("not confirmed", "Confirma tu correo antes de ingresar."),
                     ("already registered", "Ese correo ya tiene una cuenta."), ("Se necesita una invitaci", "El código de invitación no es válido o venció.")):
        if ing in m:
            return esp
    return m or "Ocurrió un error."


def dialogo(titulo, texto, botones):
    caja = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(12))
    msg = Label(text=texto, halign="center", valign="middle", color=TEXTO)
    msg.bind(size=lambda w, s: setattr(w, "text_size", (s[0], None)))
    caja.add_widget(msg)
    pop = Popup(title=titulo, content=caja, size_hint=(.92, None), height=dp(320), auto_dismiss=False,
                background="", background_color=BLANCO, title_color=TEXTO, separator_color=NARANJA)
    fila = BoxLayout(size_hint_y=None, height=dp(52), spacing=dp(8))
    for t, f in botones:
        b = Boton(t, color=NARANJA if f else CLARO, texto_color=BLANCO if f else AZUL, height=dp(48))
        b.bind(on_release=lambda *_, f=f: (pop.dismiss(), f() if f else None))
        fila.add_widget(b)
    caja.add_widget(fila)
    pop.open()
