"""Estructura principal: páginas (Inicio, Mapa, Equipo, Perfil) y barra de navegación inferior."""
from __future__ import annotations

import webbrowser
from urllib.parse import quote

from kivy.app import App
from kivy.core.clipboard import Clipboard
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import FadeTransition, Screen, ScreenManager
from kivy.uix.spinner import Spinner

from .mapa import PantallaMapa
from .tema import (AZUL, AZUL_OSC, BLANCO, CLARO, FONDO, GRIS, NARANJA, ROJO, TEXTO, VERDE, Boton, Campo, Tarjeta, dialogo,
                   en_hilo, etiqueta, pintar, texto_error)

ROLES = {"admin": "Administrador", "director": "Director", "colaborador": "Colaborador"}
ESTADOS = {"pendiente": "Pendiente", "aprobado": "Aprobado", "activo": "Activo", "suspendido": "Suspendido", "baja": "Baja"}


def _pagina(name):
    s = Screen(name=name)
    sv = ScrollView(do_scroll_x=False, bar_width=0)
    col = BoxLayout(orientation="vertical", size_hint_y=None, padding=[dp(16), dp(18), dp(16), dp(24)], spacing=dp(14))
    col.bind(minimum_height=col.setter("height"))
    sv.add_widget(col)
    s.add_widget(sv)
    return s, col


class InicioPage(Screen):
    def __init__(self, logica, ir, **kw):
        super().__init__(name="inicio", **kw)
        self.logica, self.ir = logica, ir
        sv = ScrollView(do_scroll_x=False, bar_width=0)
        self.col = BoxLayout(orientation="vertical", size_hint_y=None, padding=[dp(16), dp(18), dp(16), dp(24)], spacing=dp(14))
        self.col.bind(minimum_height=self.col.setter("height"))
        sv.add_widget(self.col)
        self.add_widget(sv)
        self.saludo = etiqueta("", 24, TEXTO, True)
        self.rol = etiqueta("", 13, GRIS)
        hero = Tarjeta(color=AZUL, radio=28, padding=dp(20))
        hero.add_widget(etiqueta("Tus visitas de hoy", 14, (1, 1, 1, .8)))
        self.hoy = etiqueta("–", 54, BLANCO, True)
        self.sub = etiqueta("", 13, (1, 1, 1, .8))
        hero.add_widget(self.hoy)
        hero.add_widget(self.sub)
        hero.add_widget(Boton("Registrar visita", on_release=lambda *_: self.ir("mapa")))
        self.n = {}
        grid = GridLayout(cols=2, spacing=dp(12), size_hint_y=None, height=dp(2 * 104 + 12))
        for clave, titulo, color in (("casas", "Casas en el mapa", AZUL), ("por_enviar", "Por enviar", NARANJA),
                                     ("visitadas", "Casas visitadas", VERDE), ("personas", "Personas con autorización", AZUL_OSC)):
            t = Tarjeta(padding=dp(14), spacing=dp(2))
            t.add_widget(etiqueta(titulo, 12, GRIS))
            self.n[clave] = etiqueta("–", 30, color, True)
            t.add_widget(self.n[clave])
            grid.add_widget(t)
        self.estado = etiqueta("", 12, GRIS)
        acciones = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(10))
        acciones.add_widget(Boton("Ver mapa", color=CLARO, texto_color=AZUL, height=dp(48), on_release=lambda *_: self.ir("mapa")))
        acciones.add_widget(Boton("Sincronizar", color=CLARO, texto_color=AZUL, height=dp(48), on_release=lambda *_: self.sincronizar()))
        for w in (self.saludo, self.rol, hero, grid, acciones, self.estado):
            self.col.add_widget(w)

    def on_pre_enter(self, *_):
        p = self.logica.perfil
        if p:
            self.saludo.text = f"Hola, {p.nombre.split()[0] if p.nombre else ''}"
            self.rol.text = ROLES.get(p.rol, p.rol)
        self.pintar(self.logica.estadisticas_locales())
        en_hilo(self.logica.estadisticas, self.pintar, lambda e: setattr(self.estado, "text", "Sin conexión: se muestran los últimos datos."))

    def pintar(self, d: dict) -> None:
        f = lambda k: str(d[k]) if d.get(k) is not None else "–"
        self.hoy.text = f("mis_visitas_hoy")
        self.sub.text = f"{f('casas')} casas registradas por el equipo"
        for k, w in self.n.items():
            w.text = f(k)
        if "en_linea" in d:
            self.estado.text = "Datos actualizados." if d["en_linea"] else "Sin conexión: se muestran los últimos datos."

    def sincronizar(self):
        self.estado.text = "Sincronizando…"
        en_hilo(self.logica.sincronizar, lambda r: (setattr(self.estado, "text", "Sin conexión: se enviará luego." if r.get("sin_conexion") else (r.get("error") or "Sincronizado.")), self.on_pre_enter()))


class EquipoPage(Screen):
    def __init__(self, logica, **kw):
        super().__init__(name="equipo", **kw)
        self.logica = logica
        sv = ScrollView(do_scroll_x=False, bar_width=0)
        col = BoxLayout(orientation="vertical", size_hint_y=None, padding=[dp(16), dp(18), dp(16), dp(24)], spacing=dp(14))
        col.bind(minimum_height=col.setter("height"))
        sv.add_widget(col)
        self.add_widget(sv)
        col.add_widget(etiqueta("Equipo", 24, TEXTO, True))
        inv = Tarjeta()
        inv.add_widget(etiqueta("Invitar a una persona", 16, TEXTO, True))
        inv.add_widget(etiqueta("Se genera un código de un solo uso. Quien lo reciba crea su cuenta con ese código.", 12, GRIS))
        self.nombre, self.cel, self.mail = Campo("Nombre completo"), Campo("Celular (opcional)", input_type="number"), Campo("Correo (opcional)")
        self.rol = Spinner(text="Colaborador", values=["Colaborador"], size_hint_y=None, height=dp(50),
                           background_normal="", background_color=CLARO, color=TEXTO)
        self.msg = etiqueta("", 13, ROJO)
        for w in (self.nombre, self.cel, self.mail, self.rol, self.msg, Boton("Crear invitación", on_release=self.invitar)):
            inv.add_widget(w)
        col.add_widget(inv)
        self.pend, self.eq = Tarjeta(), Tarjeta()
        col.add_widget(self.pend)
        col.add_widget(self.eq)

    def on_pre_enter(self, *_):
        self.rol.values = ["Colaborador", "Director"] if self.logica.perfil and self.logica.perfil.rol == "admin" else ["Colaborador"]
        self.cargar()

    def cargar(self):
        en_hilo(self.logica.equipo, self._pintar, lambda e: setattr(self.msg, "text", texto_error(e)))

    def _fila(self, tarjeta, f, texto_boton=None, accion=None, color=NARANJA):
        fila = BoxLayout(size_hint_y=None, height=dp(52), spacing=dp(8))
        fila.add_widget(etiqueta(f"{f['nombre_completo']}\n{ROLES.get(f['rol'], f['rol'])} · {ESTADOS.get(f['estado'], f['estado'])}", 13, TEXTO))
        if texto_boton:
            fila.add_widget(Boton(texto_boton, color=color, height=dp(40), size_hint_x=.38, on_release=lambda *_: accion(f)))
        tarjeta.add_widget(fila)

    def _pintar(self, filas):
        yo = self.logica.perfil.id if self.logica.perfil else None
        self.pend.clear_widgets()
        self.eq.clear_widgets()
        self.pend.add_widget(etiqueta("Solicitudes por aprobar", 16, TEXTO, True))
        pend = [f for f in filas if f["estado"] == "pendiente"]
        if not pend:
            self.pend.add_widget(etiqueta("No hay solicitudes pendientes.", 13, GRIS))
        for f in pend:
            self._fila(self.pend, f, "Aprobar", lambda f: self._accion(self.logica.aprobar, f))
        self.eq.add_widget(etiqueta("Personas del equipo", 16, TEXTO, True))
        for f in filas:
            if f["estado"] == "pendiente" or f["id"] == yo:
                continue
            if f["rol"] == "admin" or (f["rol"] == "director" and self.logica.perfil.rol != "admin"):
                self._fila(self.eq, f)
            elif f["estado"] == "suspendido":
                self._fila(self.eq, f, "Reactivar", lambda f: self._accion(self.logica.reactivar, f), VERDE)
            else:
                self._fila(self.eq, f, "Suspender", lambda f: self._accion(lambda i: self.logica.suspender(i, "Suspendida desde la app"), f), ROJO)

    def _accion(self, fn, f):
        en_hilo(lambda: fn(f["id"]), lambda _: self.cargar(), lambda e: setattr(self.msg, "text", texto_error(e)))

    def invitar(self, *_):
        self.msg.text = ""
        nombre = self.nombre.text.strip()
        if not nombre:
            self.msg.text = "Escribe el nombre de la persona."
            return
        rol = "director" if self.rol.text == "Director" else "colaborador"
        en_hilo(lambda: self.logica.invitar(nombre, self.cel.text, self.mail.text, rol), lambda r: self._listo(nombre, r),
                lambda e: setattr(self.msg, "text", texto_error(e)))

    def _listo(self, nombre, r):
        cod = r["codigo"]
        txt = f"Hola {nombre}, te invito a Pijao nos une. Descarga la app y crea tu cuenta con este código: {cod} (vence en 72 horas)."
        self.nombre.text = self.cel.text = self.mail.text = ""
        dialogo("Invitación creada", f"Código de {nombre}:\n\n{cod}\n\nSirve una sola vez y vence en 72 horas.",
                [("Copiar", lambda: Clipboard.copy(txt)), ("WhatsApp", lambda: webbrowser.open("https://wa.me/?text=" + quote(txt))), ("Cerrar", None)])


class PerfilPage(Screen):
    def __init__(self, logica, salir, **kw):
        super().__init__(name="perfil", **kw)
        self.logica = logica
        sv = ScrollView(do_scroll_x=False, bar_width=0)
        col = BoxLayout(orientation="vertical", size_hint_y=None, padding=[dp(16), dp(18), dp(16), dp(24)], spacing=dp(14))
        col.bind(minimum_height=col.setter("height"))
        sv.add_widget(col)
        self.add_widget(sv)
        col.add_widget(etiqueta("Mi perfil", 24, TEXTO, True))
        t = Tarjeta()
        self.nombre, self.rol, self.estado = etiqueta("", 18, TEXTO, True), etiqueta("", 14, GRIS), etiqueta("", 14, GRIS)
        for w in (self.nombre, self.rol, self.estado):
            t.add_widget(w)
        col.add_widget(t)
        col.add_widget(Boton("Cerrar sesión", color=CLARO, texto_color=ROJO, on_release=lambda *_: salir()))
        col.add_widget(etiqueta("Pijao nos une · versión 0.8", 12, GRIS, halign="center"))

    def on_pre_enter(self, *_):
        p = self.logica.perfil
        if p:
            self.nombre.text, self.rol.text, self.estado.text = p.nombre, ROLES.get(p.rol, p.rol), "Estado: " + ESTADOS.get(p.estado, p.estado)


class PrincipalScreen(Screen):
    def __init__(self, logica, **kw):
        super().__init__(name="principal", **kw)
        self.logica = logica
        raiz = BoxLayout(orientation="vertical")
        self.paginas = ScreenManager(transition=FadeTransition(duration=.18))
        self.mapa = PantallaMapa(logica)
        self.paginas.add_widget(InicioPage(logica, self.ir))
        self.paginas.add_widget(self.mapa)
        self.paginas.add_widget(PerfilPage(logica, self.salir))
        self.equipo = None
        self.nav = BoxLayout(size_hint_y=None, height=dp(72), padding=[dp(10), dp(8)], spacing=dp(6))
        pintar(self.nav, BLANCO, 0)
        raiz.add_widget(self.paginas)
        raiz.add_widget(self.nav)
        self.add_widget(raiz)
        self.botones = {}

    def on_pre_enter(self, *_):
        if self.logica.puede_gestionar_equipo and self.equipo is None:
            self.equipo = EquipoPage(self.logica)
            self.paginas.add_widget(self.equipo)
        items = [("inicio", "Inicio"), ("mapa", "Mapa")] + ([("equipo", "Equipo")] if self.equipo else []) + [("perfil", "Perfil")]
        self.nav.clear_widgets()
        self.botones = {}
        for clave, texto in items:
            b = Boton(texto, color=BLANCO, texto_color=GRIS, radio=22, height=dp(54), on_release=lambda _, c=clave: self.ir(c))
            self.botones[clave] = b
            self.nav.add_widget(b)
        self.ir("inicio")

    def ir(self, nombre: str) -> None:
        self.paginas.current = nombre
        for k, b in self.botones.items():
            activo = k == nombre
            b._c.rgba = (.89, .93, .99, 1) if activo else BLANCO
            b._base = b._c.rgba
            b.color = AZUL if activo else GRIS

    def salir(self) -> None:
        self.mapa.gps.detener()
        self.logica.cerrar_sesion()
        self.equipo = None
        if self.paginas.has_screen("equipo"):
            self.paginas.remove_widget(self.paginas.get_screen("equipo"))
        self.manager.current = "login"
