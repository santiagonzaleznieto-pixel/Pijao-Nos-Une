"""Interfaz Kivy (versión funcional sin diseño final: el aspecto visual se deja para el final)."""
from __future__ import annotations

import os

from kivy.app import App
from kivy.clock import Clock
from kivy.graphics import Color, Ellipse
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.checkbox import CheckBox
from kivy.uix.label import Label
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget

from ..data.localdb import LocalDB
from ..data.remoto import Remoto
from ..servicios.aplicacion import RESULTADOS, Aplicacion

CENTRO_PIJAO = (4.3333, -75.7000)   # referencia aproximada; se reemplaza por el GPS real


def _config() -> dict:
    """En Android no hay variables de entorno: se lee config.json (solo URL y clave anon, nunca service_role)."""
    import json
    ruta = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "config.json")
    try:
        with open(ruta, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


_CFG = _config()
SUPABASE_URL = os.environ.get("PIJAO_SUPABASE_URL") or _CFG.get("supabase_url", "")
SUPABASE_ANON_KEY = os.environ.get("PIJAO_SUPABASE_ANON_KEY") or _CFG.get("supabase_anon_key", "")


def aviso(pantalla: Screen, texto: str) -> None:
    pantalla.ids_msg.text = texto


def _caja() -> BoxLayout:
    return BoxLayout(orientation="vertical", padding=16, spacing=10)


class PantallaLogin(Screen):
    def __init__(self, app_logica: Aplicacion, **kw):
        super().__init__(name="login", **kw)
        self.logica = app_logica
        c = _caja()
        c.add_widget(Label(text="Pijao nos une", font_size="26sp", size_hint_y=None, height=60))
        self.correo = TextInput(hint_text="Correo", multiline=False, size_hint_y=None, height=48)
        self.clave = TextInput(hint_text="Contraseña", password=True, multiline=False, size_hint_y=None, height=48)
        self.ids_msg = Label(text="", size_hint_y=None, height=40)
        b = Button(text="Entrar", size_hint_y=None, height=52, on_release=self.entrar)
        for w in (self.correo, self.clave, b, self.ids_msg):
            c.add_widget(w)
        self.add_widget(c)

    def entrar(self, *_):
        try:
            p = self.logica.iniciar_sesion(self.correo.text, self.clave.text)
        except Exception as e:  # mensajes ya vienen en español desde la capa de datos
            return aviso(self, str(e) or "No se pudo iniciar sesión.")
        if not p.activo:
            return aviso(self, "Tu cuenta aún no está aprobada por el Director.")
        self.manager.current = "mapa"


class Lienzo(Widget):
    """Mapa simple: dibuja las viviendas guardadas como puntos (el mapa de teselas viene después)."""
    puntos: list = []

    def redibujar(self, puntos):
        self.puntos = puntos
        self.canvas.clear()
        if not puntos:
            return
        lats, lngs = [p["lat"] for p in puntos], [p["lng"] for p in puntos]
        a, b, c, d = min(lats), max(lats), min(lngs), max(lngs)
        with self.canvas:
            for p in puntos:
                x = self.x + (p["lng"] - c) / ((d - c) or 1) * (self.width - 20) + 10
                y = self.y + (p["lat"] - a) / ((b - a) or 1) * (self.height - 20) + 10
                Color(*((0.9, 0.6, 0.1) if p.get("pendiente") else (0.1, 0.6, 0.3)))
                Ellipse(pos=(x - 6, y - 6), size=(12, 12))


class PantallaMapa(Screen):
    def __init__(self, app_logica: Aplicacion, **kw):
        super().__init__(name="mapa", **kw)
        self.logica = app_logica
        c = _caja()
        self.estado = Label(text="", size_hint_y=None, height=32)
        self.lienzo = Lienzo()
        fila = BoxLayout(size_hint_y=None, height=52, spacing=8)
        fila.add_widget(Button(text="Nueva visita", on_release=lambda *_: self.manager.get_screen("visita").abrir()))
        fila.add_widget(Button(text="Sincronizar", on_release=lambda *_: self.sincronizar()))
        fila.add_widget(Button(text="Salir", on_release=self.salir))
        for w in (self.estado, self.lienzo, fila):
            c.add_widget(w)
        self.add_widget(c)

    def on_pre_enter(self, *_):
        self.refrescar()

    def refrescar(self):
        pts = [p for p in self.logica.puntos_mapa() if p.get("lat") is not None]
        self.lienzo.redibujar(pts)
        self.estado.text = f"{len(pts)} casas · {self.logica.estado_cola()['por_enviar']} por enviar"

    def sincronizar(self):
        r = self.logica.sincronizar()
        self.estado.text = "Sin conexión: se enviará luego." if r.get("sin_conexion") else (r.get("error") or "Sincronizado.")
        Clock.schedule_once(lambda *_: self.refrescar(), 1.5)

    def salir(self, *_):
        self.logica.cerrar_sesion()
        self.manager.current = "login"


class PantallaVisita(Screen):
    def __init__(self, app_logica: Aplicacion, **kw):
        super().__init__(name="visita", **kw)
        self.logica, self.draft = app_logica, None
        c = _caja()
        self.resultado = Spinner(text="Resultado de la visita", values=RESULTADOS, size_hint_y=None, height=48)
        self.notas = TextInput(hint_text="Notas (sin datos sensibles)", size_hint_y=None, height=120)
        fila = BoxLayout(size_hint_y=None, height=44)
        self.autoriza = CheckBox(size_hint_x=None, width=44)
        fila.add_widget(self.autoriza)
        fila.add_widget(Label(text="La persona autorizó el uso de sus datos"))
        self.ids_msg = Label(text="", size_hint_y=None, height=40)
        g = Button(text="Guardar visita", size_hint_y=None, height=52, on_release=self.guardar)
        v = Button(text="Volver", size_hint_y=None, height=44, on_release=lambda *_: setattr(self.manager, "current", "mapa"))
        for w in (self.resultado, self.notas, fila, self.ids_msg, g, v):
            c.add_widget(w)
        self.add_widget(c)

    def abrir(self):
        lat, lng = CENTRO_PIJAO
        self.draft = self.logica.nueva_visita(lat, lng)
        self.draft["visita"]["ubicacion_manual"] = True      # hasta conectar el GPS real
        self.draft["visita"]["motivo_manual"] = "GPS no conectado aún"
        self.resultado.text, self.notas.text, self.ids_msg.text = "Resultado de la visita", "", ""
        self.manager.current = "visita"

    def guardar(self, *_):
        v = self.draft["visita"]
        v.update(resultado=self.resultado.text, notas=self.notas.text, autorizacion_verbal=self.autoriza.active)
        try:
            self.logica.guardar_visita(self.draft)
        except ValueError as e:
            return aviso(self, str(e))
        self.manager.current = "mapa"


class PijaoApp(App):
    title = "Pijao nos une"

    def build(self):
        ruta = os.path.join(self.user_data_dir, "pijao.db")
        self.logica = Aplicacion(LocalDB(ruta), Remoto(SUPABASE_URL, SUPABASE_ANON_KEY))
        sm = ScreenManager()
        for p in (PantallaLogin, PantallaMapa, PantallaVisita):
            sm.add_widget(p(self.logica))
        if self.logica.perfil_guardado() and self.logica.perfil.activo:
            sm.current = "mapa"
        return sm
