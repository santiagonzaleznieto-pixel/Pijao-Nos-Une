"""Interfaz Kivy (versión funcional sin diseño final: el aspecto visual se deja para el final)."""
from __future__ import annotations

import os

from kivy.app import App
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.checkbox import CheckBox
from kivy.uix.label import Label
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput

from ..data.localdb import LocalDB
from ..data.remoto import Remoto
from ..servicios.aplicacion import RESULTADOS, Aplicacion
from .mapa import PantallaMapa

CENTRO_PIJAO = (4.3333, -75.7000)   # referencia aproximada; se reemplaza por el GPS real


def _config() -> dict:
    """En Android no hay variables de entorno: se lee config.json (solo URL y clave anon, nunca service_role)."""
    import json
    ruta = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "config.json")
    try:
        with open(ruta, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


_CFG = _config()
SUPABASE_URL = os.environ.get("PIJAO_SUPABASE_URL") or _CFG.get("supabase_url", "")
SUPABASE_ANON_KEY = os.environ.get("PIJAO_SUPABASE_ANON_KEY") or _CFG.get("supabase_anon_key", "")


def aviso(pantalla: Screen, texto: str) -> None:
    pantalla.ids_msg.text = texto


def _caja() -> BoxLayout:
    return BoxLayout(orientation="vertical", padding=16, spacing=10)


class PantallaLogin(Screen):
    def __init__(self, app_logica: Aplicacion, **kw):
        super().__init__(name="login", **kw)
        self.logica = app_logica
        c = _caja()
        c.add_widget(Label(text="Pijao nos une", font_size="26sp", size_hint_y=None, height=60))
        self.correo = TextInput(hint_text="Correo", multiline=False, size_hint_y=None, height=48)
        self.clave = TextInput(hint_text="Contraseña", password=True, multiline=False, size_hint_y=None, height=48)
        self.ids_msg = Label(text="", size_hint_y=None, height=40)
        b = Button(text="Entrar", size_hint_y=None, height=52, on_release=self.entrar)
        for w in (self.correo, self.clave, b, self.ids_msg):
            c.add_widget(w)
        self.add_widget(c)

    def entrar(self, *_):
        try:
            p = self.logica.iniciar_sesion(self.correo.text, self.clave.text)
        except Exception as e:  # mensajes ya vienen en español desde la capa de datos
            return aviso(self, str(e) or "No se pudo iniciar sesión.")
        if not p.activo:
            return aviso(self, "Tu cuenta aún no está aprobada por el Director.")
        self.manager.current = "mapa"


class PantallaVisita(Screen):
    def __init__(self, app_logica: Aplicacion, **kw):
        super().__init__(name="visita", **kw)
        self.logica, self.draft = app_logica, None
        c = _caja()
        self.resultado = Spinner(text="Resultado de la visita", values=RESULTADOS, size_hint_y=None, height=48)
        self.notas = TextInput(hint_text="Notas (sin datos sensibles)", size_hint_y=None, height=120)
        fila = BoxLayout(size_hint_y=None, height=44)
        self.autoriza = CheckBox(size_hint_x=None, width=44)
        fila.add_widget(self.autoriza)
        fila.add_widget(Label(text="La persona autorizó el uso de sus datos"))
        self.ids_msg = Label(text="", size_hint_y=None, height=40)
        g = Button(text="Guardar visita", size_hint_y=None, height=52, on_release=self.guardar)
        v = Button(text="Volver", size_hint_y=None, height=44, on_release=lambda *_: setattr(self.manager, "current", "mapa"))
        for w in (self.resultado, self.notas, fila, self.ids_msg, g, v):
            c.add_widget(w)
        self.add_widget(c)

    def abrir(self, lectura: dict, vivienda: dict | None = None):
        self.lectura = lectura
        self.draft = self.logica.nueva_visita(lectura["lat"], lectura["lng"], lectura.get("precision_m"), vivienda)
        self.resultado.text, self.notas.text, self.ids_msg.text = "Resultado de la visita", "", ""
        self.autoriza.active = False
        self.manager.current = "visita"

    def guardar(self, *_):
        v = self.draft["visita"]
        v.update(resultado=self.resultado.text, notas=self.notas.text, autorizacion_verbal=self.autoriza.active)
        try:
            l = self.lectura
            self.logica.guardar_visita(self.draft, {"lat": l["lat"], "lng": l["lng"], "precision_m": l.get("precision_m"), "plataforma": "android"})
        except ValueError as e:
            return aviso(self, str(e))
        self.manager.current = "mapa"


class PijaoApp(App):
    title = "Pijao nos une"

    def build(self):
        ruta = os.path.join(self.user_data_dir, "pijao.db")
        self.logica = Aplicacion(LocalDB(ruta), Remoto(SUPABASE_URL, SUPABASE_ANON_KEY))
        sm = ScreenManager()
        for p in (PantallaLogin, PantallaMapa, PantallaVisita):
            sm.add_widget(p(self.logica))
        if self.logica.perfil_guardado() and self.logica.perfil.activo:
            sm.current = "mapa"
        return sm
