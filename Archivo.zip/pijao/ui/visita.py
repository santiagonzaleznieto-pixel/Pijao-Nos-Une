"""Registro de visita: vivienda (si es nueva), resultado, autorización, seguimiento y notas."""
from __future__ import annotations

from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.checkbox import CheckBox
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import Screen
from kivy.uix.spinner import Spinner

from .tema import AZUL, CLARO, FONDO, GRIS, NARANJA, ROJO, TEXTO, Boton, Campo, Tarjeta, dialogo, en_hilo, etiqueta

RESULTADOS = [("conversacion_completa", "Conversación completa"), ("conversacion_breve", "Conversación breve"),
              ("dejo_informacion", "Dejó información"), ("nadie_en_casa", "Nadie en casa"), ("pidio_volver", "Pidió volver"),
              ("rechazo", "Rechazó"), ("pidio_no_ser_visitado", "Pidió no ser visitado"),
              ("casa_cerrada_deshabitada", "Casa cerrada o deshabitada"), ("direccion_erronea", "Dirección errónea")]
TIPOS = [("casa_urbana", "Casa urbana"), ("apartamento", "Apartamento"), ("finca_rural", "Finca o casa rural"),
         ("casa_con_local", "Casa con local"), ("lote_construccion", "Lote o en construcción"),
         ("alojamiento_turistico", "Alojamiento turístico"), ("otro", "Otro")]
CON_CONVERSACION = {"conversacion_completa", "conversacion_breve", "pidio_volver"}


def _spinner(texto, valores):
    return Spinner(text=texto, values=valores, size_hint_y=None, height=dp(50), background_normal="", background_color=CLARO, color=TEXTO)


class PantallaVisita(Screen):
    def __init__(self, app_logica, **kw):
        super().__init__(name="visita", **kw)
        self.logica, self.draft, self.lectura = app_logica, None, None
        self.sv = ScrollView(do_scroll_x=False, bar_width=0)
        self.add_widget(self.sv)

    def abrir(self, lectura: dict, vivienda: dict | None = None):
        self.lectura, self.nueva = lectura, vivienda is None
        self.draft = self.logica.nueva_visita(lectura["lat"], lectura["lng"], lectura.get("precision_m"), vivienda)
        col = BoxLayout(orientation="vertical", size_hint_y=None, padding=[dp(16), dp(18), dp(16), dp(24)], spacing=dp(14))
        col.bind(minimum_height=col.setter("height"))
        col.add_widget(etiqueta("Registrar visita", 24, TEXTO, True))
        prec = lectura.get("precision_m")
        col.add_widget(etiqueta(("Casa nueva" if self.nueva else "Agregando una visita a una casa ya registrada")
                                + (f" · ubicación ±{prec:.0f} m" if prec is not None else ""), 13, GRIS))
        if self.nueva:
            t = Tarjeta()
            t.add_widget(etiqueta("La vivienda", 16, TEXTO, True))
            self.dir, self.barrio = Campo("Dirección o indicaciones"), Campo("Barrio o vereda")
            self.tipo = _spinner("Tipo de vivienda", [e for _, e in TIPOS])
            for w in (self.dir, self.barrio, self.tipo):
                t.add_widget(w)
            col.add_widget(t)
        t = Tarjeta()
        t.add_widget(etiqueta("La visita", 16, TEXTO, True))
        self.res = _spinner("Resultado de la visita", [e for _, e in RESULTADOS])
        self.aut, self.vol, self.seg = (CheckBox(size_hint=(None, None), size=(dp(40), dp(40))) for _ in range(3))
        self.motivo = Campo("Motivo del seguimiento")
        self.notas = Campo("Notas (sin datos sensibles)", multilinea=True)
        t.add_widget(self.res)
        for ck, txt in ((self.aut, "La persona dio su autorización verbal"), (self.vol, "Entregué volante o información"),
                        (self.seg, "Hay que volver a visitar")):
            f = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
            f.add_widget(ck)
            f.add_widget(etiqueta(txt, 13, TEXTO))
            t.add_widget(f)
        t.add_widget(self.motivo)
        t.add_widget(self.notas)
        self.error = etiqueta("", 13, ROJO)
        t.add_widget(self.error)
        t.add_widget(Boton("Guardar visita", on_release=self.guardar))
        t.add_widget(Boton("Cancelar", color=CLARO, texto_color=AZUL, on_release=lambda *_: self._volver()))
        col.add_widget(t)
        self.sv.clear_widgets()
        self.sv.add_widget(col)
        self.manager.current = "visita"

    def _volver(self):
        root = App.get_running_app().root
        root.current = "principal"
        root.get_screen("principal").ir("mapa")
        root.get_screen("principal").mapa.refrescar()

    def guardar(self, *_):
        d, v = self.draft, self.draft["visita"]
        res = dict((e, k) for k, e in RESULTADOS).get(self.res.text)
        if res in CON_CONVERSACION and not self.aut.active:
            self.error.text = "Marca la autorización verbal: sin ella no se puede registrar la conversación."
            return
        v.update(resultado=res, autorizacion_verbal=self.aut.active, volante_entregado=self.vol.active,
                 seguimiento_requerido=self.seg.active, seguimiento_motivo=self.motivo.text.strip() or None,
                 notas=self.notas.text.strip() or None)
        if self.nueva:
            d["vivienda"].update(direccion=self.dir.text.strip() or None, barrio_vereda=self.barrio.text.strip() or None,
                                 tipo_vivienda=dict((e, k) for k, e in TIPOS).get(self.tipo.text))
        l = self.lectura
        try:
            self.logica.guardar_visita(d, {"lat": l["lat"], "lng": l["lng"], "precision_m": l.get("precision_m"), "plataforma": "android"})
        except ValueError as e:
            self.error.text = str(e)
            return
        en_hilo(self.logica.sincronizar)
        dialogo("Visita guardada", "Se envía sola cuando hay internet. Puedes seguir registrando.", [("Listo", self._volver)])
