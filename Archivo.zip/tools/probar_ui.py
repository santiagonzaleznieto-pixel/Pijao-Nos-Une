"""Recorre TODA la interfaz con el emulador de Kivy (sin celular): bienvenida, ingreso, reingreso con sesión guardada, inicio, mapa,
registro de visita, equipo, perfil y registro con código. Uso: python tools/probar_ui.py"""
import os
import sys
import threading

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, RAIZ)
sys.path.insert(0, os.path.join(RAIZ, "tools"))
import kivy_falso as K  # noqa: E402

K.instalar()
from pijao.data.remoto import ErrorRemoto, SinConexion  # noqa: E402
import pijao.ui.app as appmod  # noqa: E402


class RemotoPrueba:
    caido = False
    vencida = False

    def __init__(self, url="", anon="", al_cambiar_tokens=None, **k):
        self.cb, self.access_token, self.refresh_token = al_cambiar_tokens, None, None

    def cargar_tokens(self, a, r, e=0.0, u=None):
        self.access_token, self.refresh_token = a, r

    @property
    def tiene_sesion(self):
        return bool(self.refresh_token or self.access_token)

    def _red(self):
        if self.caido:
            raise SinConexion()
        if self.vencida:
            raise ErrorRemoto(401, "JWT expired")

    def iniciar_sesion(self, c, p):
        self._red()
        self.access_token, self.refresh_token = "a", "r"
        if self.cb:
            self.cb({"access_token": "a", "refresh_token": "r", "expira_en": 9e9, "usuario_id": "u1"})
        return {}

    def registrar(self, c, p, d):
        self._red()
        self.registro = d
        return {}

    def cerrar_sesion(self):
        self.access_token = self.refresh_token = None

    def seleccionar(self, t, params=None):
        self._red()
        if t == "perfiles":
            return [{"id": "u1", "nombre_completo": "Santiago", "rol": "admin", "estado": "activo"},
                    {"id": "u2", "nombre_completo": "Ana", "rol": "colaborador", "estado": "pendiente"},
                    {"id": "u3", "nombre_completo": "Luis", "rol": "colaborador", "estado": "activo"},
                    {"id": "u4", "nombre_completo": "Marta", "rol": "director", "estado": "activo"},
                    {"id": "u5", "nombre_completo": "Eva", "rol": "colaborador", "estado": "suspendido"}]
        if t == "visitas":
            return [{"id": "v1"}, {"id": "v2"}]
        return []

    def rpc(self, f, a=None):
        self._red()
        if f == "rpc_mi_perfil":
            return {"id": "u1", "nombre": "Santiago González", "rol": "admin", "estado": "activo", "permisos": []}
        if f == "rpc_invitar":
            return {"ok": True, "codigo": "ABCD1234", "expira_en": "x"}
        if f == "rpc_panel_campana":
            return {"viviendas_conocidas": 12, "viviendas_visitadas": 5, "hogares": 4, "personas_autorizadas": 9}
        if f == "rpc_registrar_visita":
            return {"ok": True, "calidad": "rojo", "motivos": [], "advertencias": [], "personas_duplicadas": []}
        return {"ok": True}


appmod.Remoto = RemotoPrueba
import pijao.ui.mapa as mapamod  # noqa: E402
from pijao.servicios.gps import Muestreo as _Muestreo  # noqa: E402
mapamod.Muestreo = lambda d=9.0: _Muestreo(d, reloj=lambda: K.Clock.t)      # el reloj de la prueba es el del emulador
paso = 0


def ok(texto):
    global paso
    paso += 1
    print(f"  {paso:2d}. {texto}")


def esperar(seg=1.0):
    for t in threading.enumerate():
        if t is not threading.main_thread():
            t.join(3)
    K.Clock.avanzar(seg)


def hay_error_en_pantallas(sm):
    from pijao.ui.errores import mostrar  # noqa: F401  (se importa para comprobar que el módulo carga)


def correr():
    app = appmod.PijaoApp()
    sm = app.build()
    app.root = sm
    ok(f"build(): pantallas {[s.name for s in sm.children][::-1]}")
    assert sm.current == "splash"
    K.Clock.avanzar(5)
    assert sm.current == "login", sm.current
    ok("bienvenida termina y va al ingreso (sin sesión)")

    login = sm.get_screen("login")
    login.on_enter()
    login.correo.text, login.clave.text = "yo@correo.co", "clave-larga-123"
    login.entrar()
    esperar()
    assert sm.current == "principal", (sm.current, login.error.text)
    ok("ingreso correcto lleva a principal")
    pr = sm.get_screen("principal")
    inicio = pr.paginas.get_screen("inicio")
    assert inicio.hoy.text != "–" and inicio.n["casas"].text == "12", (inicio.hoy.text, inicio.n["casas"].text)
    ok(f"Inicio: hoy={inicio.hoy.text}, casas={inicio.n['casas'].text}, secciones={len(inicio.tiles.children)}")
    assert set(pr.botones) == {"inicio", "mapa", "equipo", "perfil"}
    for destino in ("mapa", "equipo", "perfil", "inicio"):
        pr.ir(destino)
        esperar(.5)
    ok("navegación entre Inicio, Mapa, Equipo y Perfil")

    # ---- mapa y registro de visita
    pr.ir("mapa")
    mapa = pr.mapa
    mapa.logica.puntos_mapa = lambda: [{"id": "c1", "lat": 4.3340, "lng": -75.7010, "estado": "visitada_conversacion", "pendiente": False},
                                       {"id": "c2", "lat": 4.3350, "lng": -75.7020, "estado": "no_contactar", "pendiente": True},
                                       {"id": "c3", "lat": 4.3360, "lng": -75.7030, "estado": "por_visitar", "pendiente": False}]
    mapa.refrescar()
    esperar()
    assert len(mapa.marcadores) == 3
    ok(f"mapa: {len(mapa.marcadores)} puntos dibujados; satélite={mapa.satelite}")
    mapa.cambiar_capa()
    mapa.cambiar_capa()
    mapa._lectura({"lat": 4.3331, "lng": -75.7002, "precision_m": 8.0, "altitud_m": 1500.0})
    mapa.centrar()
    mapa._tocar_punto(mapa.marcadores[0].dato)
    mapa._tocar_punto(mapa.marcadores[1].dato)
    mapa._ocultar_ficha()
    mapa._tocar_punto(mapa.marcadores[0].dato)
    mapa._agregar_visita(mapa.marcadores[0].dato)
    assert sm.current == "visita"
    sm.current = "principal"
    ok("ficha de un punto y «agregar visita» a una casa existente")
    mapa.registrar_aqui()
    for _ in range(20):
        mapa._lectura({"lat": 4.3331, "lng": -75.7002, "precision_m": 8.0})
        K.Clock.avanzar(.5)
    assert sm.current == "visita", (sm.current, [p.title for p in K.Popup.abiertos])
    ok("«Registrar aquí»: 9 s de GPS y abre el formulario")
    v = sm.get_screen("visita")
    v.res.text, v.dir.text, v.barrio.text, v.tipo.text = "Nadie en casa", "Calle 1", "Centro", "Casa urbana"
    v.seg.active, v.motivo.text = True, "Volver mañana"
    v.guardar()
    esperar()
    assert K.Popup.abiertos and K.Popup.abiertos[-1].title == "Visita guardada"
    K.Popup.abiertos[-1].content.children[0].children[0].dispatch("on_release")
    assert sm.current == "principal"
    ok("visita guardada en la cola y enviada")
    v.abrir({"lat": 4.3, "lng": -75.7, "precision_m": 5.0}, None)
    v.res.text = "Conversación completa"
    v.guardar()
    assert "autorización" in v.error.text
    ok("sin autorización verbal no deja guardar una conversación")
    sm.current = "principal"
    mapa._fin_muestreo(None)
    mapa._fin_muestreo({"lat": 4.3, "lng": -75.7, "precision_m": 55.0})
    mapa._fin_muestreo({"lat": 4.3340, "lng": -75.7010, "precision_m": 5.0})
    ok("avisos de GPS sin señal, precisión débil y casa duplicada")

    # ---- equipo
    pr.ir("equipo")
    eq = pr.equipo
    esperar()
    eq.nombre.text = "Nuevo Colaborador"
    eq.invitar()
    esperar()
    assert any("Invitación creada" == p.title for p in K.Popup.abiertos)
    ok("invitación creada con código")
    eq._accion(app.logica.aprobar, {"id": "u2"})
    esperar()
    ok("aprobar y suspender desde Equipo")

    # ---- perfil y salida
    pr.ir("perfil")
    assert sm.get_screen("principal").paginas.get_screen("perfil").nombre.text
    appmod.PijaoApp  # noqa: B018
    pr.salir()
    assert sm.current == "login"
    ok("cerrar sesión vuelve al ingreso")

    # ---- registro con código
    login.on_pre_enter()
    sm.current = "registro"
    r = sm.get_screen("registro")
    r.codigo.text, r.nombre.text, r.correo.text, r.clave.text, r.celular.text = "abcd1234", "Ana Prueba", "ana@correo.co", "clave-muy-larga-1", "3001112233"
    r.crear()
    assert "18" in r.error.text or "mayor" in r.error.text
    r.mayor.active = True
    r.crear()
    esperar()
    assert any("Cuenta creada" == p.title for p in K.Popup.abiertos)
    ok("registro con código de invitación")

    # ---- sesión guardada: cerrar y abrir de nuevo la app (el fallo que cerraba la aplicación)
    sm.current = "login"
    login.correo.text, login.clave.text = "yo@correo.co", "clave-larga-123"
    login.entrar()
    esperar()
    carpeta = app.user_data_dir
    app2 = appmod.PijaoApp()
    app2.user_data_dir = carpeta
    sm2 = app2.build()
    app2.root = sm2
    K.Clock.avanzar(5)
    assert sm2.current == "principal", sm2.current
    ok("reabrir la app con sesión guardada entra directo a principal")
    # ---- sin internet
    RemotoPrueba.caido = True
    sm2.get_screen("principal").paginas.get_screen("inicio").on_pre_enter()
    esperar()
    ok("sin internet: Inicio muestra los últimos datos")
    # ---- sesión vencida: vuelve al ingreso
    RemotoPrueba.caido, RemotoPrueba.vencida = False, True
    sm2.get_screen("principal").paginas.get_screen("inicio").on_pre_enter()
    esperar()
    assert sm2.current == "login", sm2.current
    RemotoPrueba.vencida = False
    ok("sesión vencida: la app vuelve al ingreso en vez de quedarse sin datos")
    # ---- una pantalla que falla al construirse no tumba la app
    original = appmod.LoginScreen

    class Rota(original):
        def __init__(self, *a, **k):
            raise TypeError("falla de prueba")
    appmod.LoginScreen = Rota
    sm3 = appmod.PijaoApp().build()
    appmod.LoginScreen = original
    assert sm3.has_screen("login") and sm3.has_screen("principal")
    ok("si una pantalla falla, la app abre igual y muestra el error")


if __name__ == "__main__":
    print("Prueba completa de la interfaz con el emulador de Kivy:")
    try:
        correr()
    except Exception:
        import traceback
        traceback.print_exc()
        sys.exit(1)
    print("TODO BIEN: la interfaz recorrió todos los flujos sin errores.")
