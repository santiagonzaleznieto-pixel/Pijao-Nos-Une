"""Crea la cuenta de Administrador (una sola vez) con el código de instalación.
Uso:  python tools/crear_admin.py
Necesita Python 3 y ninguna librería extra. Lee la URL y la clave anon de config.json."""
import getpass
import json
import os
import urllib.error
import urllib.request

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
cfg = json.load(open(os.path.join(RAIZ, "config.json"), encoding="utf-8"))

correo = input("Tu correo: ").strip()
nombre = input("Tu nombre completo: ").strip()
clave = getpass.getpass("Contraseña (mínimo 12 caracteres): ")
token = getpass.getpass("Código de instalación: ").strip()
if len(clave) < 12:
    raise SystemExit("La contraseña debe tener al menos 12 caracteres.")

cuerpo = json.dumps({"email": correo, "password": clave,
                     "data": {"bootstrap_token": token, "nombre_completo": nombre}}).encode()
req = urllib.request.Request(cfg["supabase_url"] + "/auth/v1/signup", data=cuerpo, method="POST",
                             headers={"apikey": cfg["supabase_anon_key"], "Content-Type": "application/json"})
try:
    with urllib.request.urlopen(req, timeout=30) as r:
        print("Listo. Revisa tu correo y confirma la cuenta; luego entra a la app.")
except urllib.error.HTTPError as e:
    print("No se pudo crear la cuenta:", e.read().decode("utf-8", "ignore")[:300])
